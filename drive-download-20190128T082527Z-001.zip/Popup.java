import java.util.*;
import javax.swing.*;
import java.awt.*;

/** Represents the GUI for the popup.
*/
public class Popup{
/** Used for pop-ing the popup boxes.
 * @param infoMessage The message to be present.
 * @param titleBar The title of the popup bar.
*/
    public static void infoBox(String infoMessage, String titleBar)
    {
        JOptionPane.showMessageDialog(null, infoMessage, "" + titleBar, JOptionPane.INFORMATION_MESSAGE);
    }
}