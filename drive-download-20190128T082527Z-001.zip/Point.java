import java.util.*;
import java.io.*;

//-----Wana-----
/** Represents the coordinate and location of the piece and tile on the board.
*/
public class Point implements Serializable{
	int x,y;
/** Create an instance of the point.
 * @param x The location of the x-axis.
 * @param y The location of the y-axis.
*/
	public Point(int x,int y){
		this.x=x;
		this.y=y;
	}
/** Used to set the x-axis.
 * @param x The location of the x-axis.
*/	
	public void setX(int x){
		this.x=x;
	}
/** Used to set the y-axis.
 * @param y The location of the y-axis.
*/		
	public void setY(int y){
		this.y=y;
	}
/** Gets the current x-axis.
 * @return The current x-axis.
*/	
	public int getX(){
		return x;
	}
/** Gets the current y-axis.
 * @return The current y-axis.
*/		
	public int getY(){
		return y;
	}
/** Used to show the current coordinate in the (x,y) concept.
 * @return The coordinate/point of an object.
*/	
	public String toString(){
		return "x: " + getX() + " ,y: " + getY();
	}
}