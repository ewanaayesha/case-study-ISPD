import java.util.*;
import java.awt.Toolkit; 
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.io.*;

/** Represents the main IChess GUI menu and toolbar.
*/
public class IChess extends JFrame {
	Board game = new Board(); 
	public static void main(String[] args){
		IChess IChessMain = new IChess();
		
	}
	
  //-----Irfan-----
/** Creates an instance of IChess.
*/
	public IChess(){
		//Define the size of the frame
		this.setSize(1000,700);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		createGUI();
	}
	  //-----Irfan / Fattah-----
/** Used to create the Menu GUI.
*/
	public void createGUI(){
		//Title of the frame
        this.setTitle("Myrmidon Chess");
        
		JMenuBar tableMenuBar = new JMenuBar();
		popMenuBar(tableMenuBar);
        this.setJMenuBar(tableMenuBar);  	

        JLabel p1 = new JLabel("Player 1");
        JLabel p2= new JLabel("Player 2");
        
        JPanel panel1 = new JPanel();
        panel1.setBackground(new Color(220,20,60));
        panel1.setPreferredSize(new Dimension(50, 50));

        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.WHITE);
        panel2.setPreferredSize(new Dimension(50, 50));

        JPanel panel3 = new JPanel();
        panel3.setBackground(Color.WHITE);
        panel3.setPreferredSize(new Dimension(50, 50));

        JPanel panel4 = new JPanel();
        panel4.setBackground(new Color(65,105,225));
        panel4.setPreferredSize(new Dimension(50, 50));

        JToolBar sideBar = new JToolBar();
        sideBar.setFloatable(false);
        this.add(sideBar, BorderLayout.WEST);

        sideBar.setOrientation(SwingConstants.VERTICAL);
        sideBar.add(p2);
        sideBar.add(panel1);
        sideBar.add(panel2);
        JButton forfeitButton = new JButton("Forfeit");
        sideBar.add(forfeitButton);
        sideBar.add(panel3);
        sideBar.add(panel4);
        sideBar.add(p1);
		//forfeit feature
        forfeitButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				forfeitGame();
			}
		}); 
		Board bb = new Board();
		game = bb;
		this.add(bb);
		this.setVisible(true);
	}
	
    //-----Irfan-----
/** Creates a pop menu bar on top of the panel.
 * @param tableMenuBar The IChess's menu bar.
*/
	public void popMenuBar(JMenuBar tableMenuBar){
		tableMenuBar.add(CreateFileMenu());
		tableMenuBar.add(CreateOptionMenu());
		tableMenuBar.add(CreateHelpMenu());
	}
	
    //-----Irfan-----
/** Used to create the hover-file menu bar option.
 * @return A JMenu object representing the file menu.
*/
	public JMenu CreateFileMenu(){
		JMenu fileMenu = new JMenu("File");
		JMenuItem newOption = new JMenuItem("New game");
		JMenuItem closeGame = new JMenuItem("Exit");
		newOption.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				JOptionPane.showMessageDialog(null, "New game loading..");
				newGame();			 
			}
		});
		closeGame.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				System.exit(0);
			}
		});
		fileMenu.add(newOption);
		fileMenu.add(closeGame);
		return fileMenu;
	}
	
    //-----Irfan-----
/** Used to create the hover-option menu bar.
 * @return A JMenu object representing the option menu.
*/
	public JMenu CreateOptionMenu(){
		JMenu optionMenu = new JMenu("Option");
		JMenuItem saveOption = new JMenuItem("Save game");
		JMenuItem loadOption = new JMenuItem("Load game");
		
		
		
		saveOption.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				JOptionPane.showMessageDialog(null, "Saving game...");
				saveGame();
			}	
		});
		
		loadOption.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				JOptionPane.showMessageDialog(null, "Loading game....");	
				loadGame();
			}		
		});
		
		optionMenu.add(saveOption);
		optionMenu.add(loadOption);
		return optionMenu;
		
	}
  
//-----Irfan / Fattah-----
/** Used to create the hover-help menu bar option.
 * @return A JMenu object representing the help menu.
*/
	public JMenu CreateHelpMenu(){
		JMenu helpMenu = new JMenu("Help");
		JMenuItem showGuide = new JMenuItem("How to play the game");
		JMenuItem aboutDev = new JMenuItem("About");
		showGuide.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				JOptionPane.showMessageDialog(null, "|Welcome to Myrmidon Chess|\n\n"
                + "- The game is played by 2 players, Player 1 & Player 2 on a 6X7 board.\n"
                + "- On the board, there are 14 chess pieces all together with 7 on each side\n"
                + "- Each players have control of the pieces on each side respectively\n"
                + "- There are 4 different types of pieces out of the 14: \n"
                + "   i  . PLUS     = Can move vertically or horizontally, up to 2 steps in any direction in a straight line.\n"
                + "   ii . Triangle = Can move diagonally, both up and down, up to 2 steps in any direction in a straight line.\n"
                + "   iii. Chevron  = Must move in an L shape, exactly two steps then 1 step right or left. (This is the only piece that can jump over other pieces.)\n"
                + "   iv . Sun      = Can move only 1 step in any direction.\n"
                + "- The game ends when the Sun is captured by the other side.\n"
                + "* After 3 turns, a Plus will turn into a Triangle, a Triangle will turn into a Chevron, and a Chevron will turn into a Plus.\n"
                + "\n~GOOD LUCK & HAVE FUN~"
                );
			}
		});
		aboutDev.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){  
				JOptionPane.showMessageDialog(null, ("DEVELOPERS\n"
                +"Faiq     - 1161102149\n"
                +"Irfan    - 1161102437\n"
                +"Wana  - 1161102091\n"
                +"Fattah - 1161102372"));
			}
		});
		helpMenu.add(showGuide);
		helpMenu.add(aboutDev);
		return helpMenu;
	}

  //-----Irfan / Faiq-----
/** Used to save the game (save all the tile objects in the game).
*/
	public void saveGame(){
		Tile[] saveArray = game.getTileArray(); //copy tilearray to saveArray
		try{  // Catch errors in I/O if necessary.
			// Open a file to write to, named SavedObj.sav.
			FileOutputStream saveFile=new FileOutputStream("SaveObj.txt");

			// Create an ObjectOutputStream to put objects into save file.
			ObjectOutputStream save = new ObjectOutputStream(saveFile);

			// Now we do the save.
			for (int i =0 ; i<42 ; i++){ //if saveArray contains object, directly write to SaveObj.txt
				if (saveArray[i].getPieceImageName() != null){
					save.writeObject(saveArray[i]);
				}
				else{ //if saveArray is null, create dummy object to avoid NullPointerException
					Piece piece = new Piece();
					saveArray[i].setPiece(piece, "empty.png", 0);
					save.writeObject(saveArray[i]);
					
				}
			}

			// Close the file.
			save.close(); // This also closes saveFile.
		}
		catch(Exception exc){
			exc.printStackTrace(); // If there was an error, print the info.
		}	
	}

  //-----Irfan / Faiq-----
/** Used to load the game (load all the tile objects in the game).
*/
	public void loadGame(){
		Tile[] loadArray = new Tile [42];	
		try{
			// Open file to read from, named SavedObj.sav.
			FileInputStream saveFile = new FileInputStream("SaveObj.txt");

			// Create an ObjectInputStream to get objects from save file.
			ObjectInputStream save = new ObjectInputStream(saveFile);

			
			for (int i =0 ; i<42 ; i++){
				loadArray[i] = (Tile) save.readObject(); //load contents of SaveObj.txt to loadArray
				game.setTileArray(i, loadArray); //pass loadArray to method setTileArray (line 430)
			}
			
			// Close the file.
			save.close(); // This also closes saveFile.
			}
		catch(Exception exc){
			exc.printStackTrace(); // If there was an error, print the info.
		}
	}

    //-----Irfan-----
/** Used to create and initialize a new game.
*/
	public void newGame(){
		dispose();
		new IChess();
	}

    //-----Fattah-----
/** Used to forfeit the game .
*/
	public void forfeitGame(){
		if ((game.getTurn(game.getCount())) == "red"){
			int replyP1 = JOptionPane.showConfirmDialog(null, "The winnner is Player 1\nDo you want to play again?", "CONGRATULATIONS!!!", JOptionPane.YES_NO_OPTION);
			if (replyP1 == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(null, "GOOD LUCK TO BOTH OF YOU! MAY THE BEST WIN :)");
				dispose();
				new IChess();
			}
			else {
				JOptionPane.showMessageDialog(null, "THANKS FOR PLAYING! GOODBYE :(");
				System.exit(0);
			}
		}
		else if ((game.getTurn(game.getCount())) == "blue"){
			int replyP2 = JOptionPane.showConfirmDialog(null, "The winnner is Player 2\nDo you want to play again?", "CONGRATULATIONS!!!", JOptionPane.YES_NO_OPTION);
			if (replyP2 == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(null, "GOOD LUCK TO BOTH OF YOU! MAY THE BEST WIN :)");
				dispose();
				new IChess();
			}
			else {
				JOptionPane.showMessageDialog(null, "THANKS FOR PLAYING! GOODBYE :(");
				System.exit(0);
			}
		}
	}
}