import java.util.*;
import javax.swing.*;
import java.io.Serializable;

//-----Wana-----
/** Represents the pieces on the board.
*/
public class Piece implements Serializable { 
	public Point currentPoint;
	public Point newPoint;
	String imageName;
/** Create an instance of the piece object.
*/	
	Piece() {}

/** Gets the validation if the piece movement is valid or invalid.
 * @param currentPoint The current point of the tile.
 * @return The boolean whether the movement of the piece is true or false.
*/	
	public boolean moveable(Point currentPoint) {
		System.out.println("No piece is selected");
		return false;
	}

/** Gets the current coordinate of the piece.
 * @return The current point of the piece.
*/	
	public Point getPoint() {
		System.out.println("x : " + currentPoint.getX() + " y: " + currentPoint.getY());
		return currentPoint;
	}
/** Used to set the point for the piece.
 * @param currentPoint The current point of the tile.
*/
	public void setCurrentPoint(Point currentPoint) {
		this.currentPoint = currentPoint;
	}
/** Gets the movement validation of the next tile.
 * @param newPoint The new coordinate of the tile.
 * @return The boolean whether the movement of the piece is true or false.
*/
	public boolean betTile(Point newPoint) {
		return false;
	}
/** Gets the point/coordinate of the next tile.
 * @param newPoint The new coordinate of the tile.
 * @return The new point of the piece.
*/
	public Point betTilePoint(Point newPoint) {
		return newPoint;
	}

}



