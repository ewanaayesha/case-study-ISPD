import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

/** Buttons that holds a Point and atmost one Piece
	*@author wana, Faiq
*/
public class Tile extends JButton implements Serializable{
	private Point Point;
	private String imageName;
	transient ImageIcon iconType;
	private int morph;
	private Piece piece = new Piece();
	
	Tile(){}
	
	Tile(Point Point){
		this.Point = Point;	
		this.piece = piece;
	}
	/** Constructor of Tile.
	 * @param point The location in the format of Point.
	 * @param piece The Piece assigned to this tile.
	*/
	Tile(Point Point, Piece piece){
		this.Point = Point;	
		this.piece = piece;
	}
	
	/** gets Piece from this tile.
	 * @return piece Piece in this Tile.
	*/
	public Piece getPiece(){
		return piece;
	}
	/** Gets point of this tile.
	 * @return piece Piece in this Tile.
	*/
	public Point getPoint(){
		return Point;
	}
	/** Gets point of this tile.
	 *@param p Piece 
	 *@param g String name of the image icon
	 *@param morph int indicator to when the Piece is ready to be morph
	*/
	public void setPiece(Piece p, String g, int morph){
		this.piece = p;
		this.imageName = g;
		this.morph = morph;
		ImageIcon iconType = new ImageIcon(imageName);
		setIcon(iconType);
		if(p != null){ 
			p.setCurrentPoint(Point);
		}
	}
	
	/** Gets image name of the tile (image of a piece)
	 * @return imageName String of image name.
	*/
	public String getPieceImageName(){
		return imageName;
	}
	
	/** Gets the morph integer 
	 * @return piece Piece in this Tile.
	*/
	public int getMorph(){
		return morph;
	}
	
	public String toString(){
		return String.valueOf(Point.getX()) +"," + String.valueOf(Point.getY());
	}
	
}