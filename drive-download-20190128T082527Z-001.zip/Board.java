import java.util.*;
import java.awt.Toolkit; 
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

/** Represents the chess board in the game IChess.
*/
public class Board extends JPanel{
	//creating an array of 42 tile buttons
	Tile[] tilearray = new Tile[42];
	Piece piece = new Piece();
	
	int click1 = 80, click2, count = 1;
	boolean redMorph = false;
	String playerColor, turn;
  
  //-----Irfan / Faiq / Ewana-----
/** Create an instance of the board.
*/
	Board(){
		super(new GridLayout(6,7));
		int a = 1 , b = 1;
		for(int i=0; i<42; i++){
			if (b > 7){
				a++;
				b=1;
			}
			Point p = new Point(a,b);
			Tile tile_obj = new Tile(p);
			
			tile_obj.addActionListener(new ActionListener(){  
				
				public void actionPerformed(ActionEvent e){
					
					String search = tile_obj.getPieceImageName();
					if ((click1 == 80) && (search != null)){ //click1 = 80 is the condition we set to make sure that this is the first click & search != null make sure there is piece in the tile
						
						getTurn(count);
						
						playerColor = tile_obj.getPieceImageName();
						if(playerColor.toLowerCase().contains(turn.toLowerCase())){ //if player click on the correct tile with his piece inside
							firstClick (tile_obj.getPoint()); 												//the click will be registered as the first click, click1 = tile array number
						}
						
							
						else{
							if(turn.toLowerCase().contains("blue".toLowerCase())){ //if player click on other player piece when it is his turn, popup will appear to show current turn
								Popup.infoBox("Player 1 (Blue) Turn!", "Sorry");
							}
							else{
								Popup.infoBox("Player 2 (Red) Turn!", "Sorry");
							}
						}
					}
					else if (click1 < 80){ //this condition will only occur if click1 has been set to any tile array number
						if (search != null){ //if click2 tile (where the piece will be moved) contains another piece
							if(search.toLowerCase().contains(turn.toLowerCase())){ //check if click2 tile contains own team's piece and,
								tileTeam(tile_obj.getPiece(), click1, click2);       //deny movement, reset click1 = 80, do not update player turn
							}
							else if ((search.toLowerCase().contains("Sun".toLowerCase())) && (turn=="red")){
								click2 = gettilearnum(tile_obj.getPoint());
								if (movePiece(click1,click2) == true){
									tileEnemy(tile_obj.getPiece(), click1, click2);
									player2Wins();
								}
								else{
									System.out.println("INVALID MOVE");
								}
							}
							else if ((search.toLowerCase().contains("Sun".toLowerCase())) && (turn=="blue")){
								click2 = gettilearnum(tile_obj.getPoint());
								if (movePiece(click1,click2) == true){
									tileEnemy(tile_obj.getPiece(), click1, click2);
									player1Wins();
								}
								else{
									System.out.println("INVALID MOVE");
								}
							}
							else{ //this condition will occur if click2 tile contains another piece but not from the same team (move to capture opponent's piece)
								click2 = gettilearnum(tile_obj.getPoint());
								System.out.println("Movable : " + movePiece(click1,click2));
								if (movePiece(click1,click2) == true){
									tileEnemy(tile_obj.getPiece(), click1, gettilearnum(tile_obj.getPoint())); //replace content of tilearray with own piece
									count++; //update player turn
									if ((count%6 == 0) || (redMorph == true)){ //count%6 == 0 will happen if it is P1's(blue) turns to transform
										for (int i = 0; i < 42; i++){						 //& redMorph == true will happen if it is P2's(red) turns to transform
											if ((tilearray[i].getMorph() == 1) && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){ //morph == 1 means object is a Plus
												plusToTriangle(tilearray[i].getPoint(), i, turn);																											//contains ensure only 1 player's piece will be transformed
											}																																																				//at a time
											else if ((tilearray[i].getMorph() == 2)  && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){ //morph == 2 means object is a Triangle
												triangleToChevron(tilearray[i].getPoint(), i, turn);
											}
											else if ((tilearray[i].getMorph() == 3) && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){ //morph == 3 means object is a Chevron
												chevronToPlus(tilearray[i].getPoint(), i, turn);
											}											
										}
										if (count%6 == 0){
											redMorph = true; //P2(red) will be transformed straightly after P1 transform
										}
										else{
											redMorph = false; //redMorph = false after P2 has successfully transformed
										}
								}
									
								}
								
								else{
									System.out.println("INVALID MOVE"); 
								}
							}click1 = 80;
						}
						else{ //this condition will occur if search == null (no other piece in the next tile)
							int click2 = gettilearnum(tile_obj.getPoint());
							System.out.println("Movable : " + movePiece(click1,click2));
							if (movePiece(click1,click2) == true){
								tileEmpty(tile_obj.getPiece(), click1, click2); //check if click2 tile is empty
								count++; //next player's turn
								if ((count%6 == 0) || (redMorph == true)){ //refer to transform's explanation above
									for (int i = 0; i < 42; i++){
										if ((tilearray[i].getMorph() == 1) && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){
											plusToTriangle(tilearray[i].getPoint(), i, turn);
										}
										else if ((tilearray[i].getMorph() == 2)  && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){
											triangleToChevron(tilearray[i].getPoint(), i, turn);
										}
										else if ((tilearray[i].getMorph() == 3) && (tilearray[i].getPieceImageName().contains(turn.toLowerCase()))){
											chevronToPlus(tilearray[i].getPoint(), i, turn);
										}											
									}
									if (count%6 == 0){
										redMorph = true;
									}
									else{
										redMorph = false;
									}
								}
							}
							
							else{
								System.out.println("INVALID MOVE"); 
							}
							click1 = 80;
							
						}
						
					
					}
					else{
						System.out.println("No piece here");
						
					}
				}
			});
		
				
			  
			tilearray[i]=(tile_obj);
			this.add(tilearray[i]);
			if(i%2 == 0){
				tilearray[i].setBackground(new Color(255,250,250));
			}
			else if(i%2 == 1){
				tilearray[i].setBackground(new Color(143,188,143));
			}
			b++;
		}
		
		
		
			arrange();		
				
	}
	//-----Wana-----
/** Gets the array of the tile
 * @return A tile array representing all the tiles in the board.
*/	
	public Tile[] getTileArray() {
        return tilearray;
    }
	
  //-----Irfan / Faiq-----
/** Set the tile into an array of tile.
 * @param i The iteration of the tile array.
 * @param tile The tile that is going to be put into the array of tile.
*/
	public void setTileArray(int i,Tile[] tile) {
			if ((tile[i].getPieceImageName().toLowerCase()).contains("empty".toLowerCase())){ //if tile[] contains dummy object, the object will be eliminated
					tilearray[i].setPiece(null, null, 0);
			}
			else{
					tilearray[i].setPiece(tile[i].getPiece(), tile[i].getPieceImageName(), tile[i].getMorph()); //modify all tilearray based on loaded file
			}
			
  }
/** Gets the iteration/count
 * @return An interger that is used to count the instance.
*/		
	public int getCount(){
		return count;
	}
	
  ////-----Wana-----
/** Gets the tile array number/ID. A formula is used to convert Point to tilearray number.
 * @param p The point/coordinate of the tile object.
 * @return The result/tile array number/ID of the tile.
*/
	public int gettilearnum(Point p){ //a formula to convert Point to tilearray number
		int x = (int) p.getX();
		int y = (int) p.getY();
		int result = (x-1)*7 +(y -1);
		return result;
	}
	
  //-----Faiq-----
/** Gets the turn which means whos turn is it now.
 * @param count The current number of iteration.
 * @return The current turn of the system. eg; Player 1's / Blue turn.
*/
	public String getTurn(int count){
			if (count%2 == 0){
				turn = "red"; //even number = red
			}
			else{
				turn = "blue"; //odd number = blue
			}
			return turn; //return current turn based on count%2
		}
		
//-----Wana-----
/** Gets the validation if the piece movement is valid or invalid.
 * @param click1 The first piece on any tile the user clicks.
 * @param click2 The next piece of tile the user clicks.
 * @return The boolean whether the movement of the piece is true or false.
*/
	public boolean movePiece(int click1,int click2){
		boolean ret = true;
		if (tilearray[click1].getPiece().moveable(tilearray[click2].getPoint()) == true){
			ret = true; //see if movement is valid according to Piece's ability
			if(tilearray[click1].getPiece().betTile(tilearray[click2].getPoint()) == true){
				//check if theres something in between the current Point to the destination Point
        //applies only for Triangle and Plus
				int check = gettilearnum(tilearray[click1].getPiece().betTilePoint(tilearray[click2].getPoint()));
				if (tilearray[check].getPieceImageName() != null){
					ret = false;
					System.out.println("Piece in the way");
				}
				else if(tilearray[check].getPieceImageName() == null){
					System.out.println("Youre good to go");
					ret = true;
				}
			}
		}
		else{
			ret = false;
		}
		
		return ret;
		
	}
	//-----Faiq-----
/** Used to find what piece and where is the piece on the first click of the player.
 * @param Point The coordinate of the piece/tile object.
*/
	public void firstClick(Point Point){
		click1 = gettilearnum(Point);
		System.out.println("===================================================");
		System.out.println("current Point: " + click1 );
	}
	
  //-----Faiq-----
/** Used to check if the tile has no piece on it.
 * @param piece The piece on the tile.
 * @param click1 The first piece on any tile the user clicks.
 * @param click2 The next piece of tile the user clicks.
*/
	public void tileEmpty(Piece piece, int click1, int click2){ //check if tile is empty and validate movement
		this.piece = piece;
		System.out.println(piece);
		tilearray[click2].setPiece(tilearray[click1].getPiece(), tilearray[click1].getPieceImageName(), (tilearray[click1].getMorph()));	
		tilearray[click1].setPiece(null ,null, 0);
		System.out.println("===================================================");
		System.out.println("Movement successful");
	}
	
  //-----Faiq-----
/** Used to check if the tile has enemy's piece on it.
 * @param piece The piece on the tile.
 * @param click1 The first piece on any tile the user clicks.
 * @param click2 The next piece of tile the user clicks.
*/
	public void tileEnemy(Piece piece, int click1, int click2){ //check if tile contains enemy pieces and capture enemy
		tilearray[click2].setPiece(tilearray[click1].getPiece(), tilearray[click1].getPieceImageName(), (tilearray[click1].getMorph()));	
		tilearray[click1].setPiece(null ,null, 0);
		System.out.println("===================================================");
		System.out.println("Enemy captured");
	}
	
  //-----Faiq-----
/** Used to check if the tile has own piece on it.
 * @param piece The piece on the tile.
 * @param click1 The first piece on any tile the user clicks.
 * @param click2 The next piece of tile the user clicks.
*/
	public void tileTeam(Piece piece, int click1, int click2){ //check if tile contains team piece and deny movement
		System.out.println("===================================================");
		System.out.println("There's another ally piece in this tile");
	}
	
  //-----Faiq-----
/** Used to morph the plus piece into triangle piece.
 * @param p The coordinate of the piece/tile object.
 * @param click2 The next piece of tile the user clicks.
 * @param turn The current turn of the system. e.g ; Player 1's turn.
*/
	public void plusToTriangle(Point p, int click2, String turn){ //create new object and load to tilearray based on transformation required
		int y = (int) p.getX();
		int x = (int) p.getY();
		if (turn == "red"){
			Piece triangleRedx = new Triangle(new Point(x, y));
			tilearray[click2].setPiece(triangleRedx, "triangle_red.png", 2);
		}
		else{
			Piece triangleBluex = new Triangle(new Point(x, y));
			tilearray[click2].setPiece(triangleBluex, "triangle_blue.png", 2);
		}		
	}
	
  //-----Faiq-----
/** Used to morph the triangle piece into chevron piece.
 * @param p The coordinate of the piece/tile object.
 * @param click2 The next piece of tile the user clicks.
 * @param turn The current turn of the system. e.g ; Player 1's turn.
*/
	public void triangleToChevron(Point p, int click2, String turn){ //create new object and load to tilearray based on transformation required
		int y = (int) p.getX();
		int x = (int) p.getY();
		if (turn == "red"){
			Piece chevronRedx = new Chevron(new Point(x, y));
			tilearray[click2].setPiece(chevronRedx, "chev_red.png", 3);
		}
		else{
			Piece chevronBluex = new Chevron(new Point(x, y));
			tilearray[click2].setPiece(chevronBluex, "chev_blue.png", 3);
		}
	}

  //-----Faiq-----
/** Used to morph the chevron piece into plus piece.
 * @param p The coordinate of the piece/tile object.
 * @param click2 The next piece of tile the user clicks.
 * @param turn The current turn of the system. e.g ; Player 1's turn.
*/
	public void chevronToPlus(Point p, int click2, String turn){ //create new object and load to tilearray based on transformation required
		int y = (int) p.getX();
		int x = (int) p.getY();
		if (turn == "red"){
			Piece plusRedx = new Plus(new Point(x, y));
			tilearray[click2].setPiece(plusRedx, "plus_red.png", 1);
		}
		else{
			Piece plusBluex = new Plus(new Point(x, y));
			tilearray[click2].setPiece(plusBluex, "plus_blue.png", 1);
		}
	}	
	
  //-----Irfan-----
/** Used for arranging all the instantied piece at start of the game.
*/
	public void arrange(){
		Piece plusRed1 = new Plus(new Point(1,1));
		Piece plusRed2 = new Plus(new Point(7,1));
		Piece plusBlue1 = new Plus(new Point(1,6));
		Piece plusBlue2 = new Plus(new Point(7,6));
		
		Piece triangleRed1 = new Triangle(new Point(2,1));
		Piece triangleRed2 = new Triangle(new Point(6,1));
		Piece triangleBlue1 = new Triangle(new Point(2,6));
		Piece triangleBlue2 = new Triangle(new Point(6,6));
		
		Piece chevRed1 = new Chevron(new Point(3,1));
		Piece chevRed2 = new Chevron(new Point(5,1));
		Piece chevBlue1 = new Chevron(new Point(3,6));
		Piece chevBlue2 = new Chevron(new Point(5,6));
		
		Piece sunRed = new Sun(new Point(4,1));
		Piece sunBlue = new Sun(new Point(4,6));
		
		tilearray[0].setPiece(plusRed1, "plus_red.png", 1); 
		tilearray[6].setPiece(plusRed2, "plus_red.png", 1); 
		tilearray[35].setPiece(plusBlue1, "plus_blue.png", 1); 
		tilearray[41].setPiece(plusBlue2, "plus_blue.png", 1); 
		
		tilearray[1].setPiece(triangleRed1, "triangle_red.png", 2); 
		tilearray[5].setPiece(triangleRed2, "triangle_red.png", 2); 
		tilearray[36].setPiece(triangleBlue1, "triangle_blue.png",2);
		tilearray[40].setPiece(triangleBlue2, "triangle_blue.png",2);
		
		tilearray[2].setPiece(chevRed1, "chev_red.png",3); 
		tilearray[4].setPiece(chevRed2, "chev_red.png",3); 
		tilearray[37].setPiece(chevBlue1, "chev_blue.png",3); 
		tilearray[39].setPiece(chevBlue2, "chev_blue.png",3); 
		
		tilearray[3].setPiece(sunRed, "sun_red.png",20); 
		tilearray[38].setPiece(sunBlue, "sun_blue.png",20); 
	}
	
/** Used to declare that Player 1 wins.
*/	
	public void player1Wins(){
		JOptionPane.showMessageDialog(null, ("Congratulation Player 1!!! You win!"),"Thank You For Playing IChess",JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
	}
	
/** Used to declare that Player 2 wins.
*/	
	public void player2Wins(){
		JOptionPane.showMessageDialog(null, ("Congratulation Player 2!!! You win!"),"Thank You For Playing IChess",JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
	}
	
	
}
